setwd("C:/Users/tim/Documents/Studium/WWU/VWL_Master/3_Semester/Macroeconometrics/Tim_Luediger_Applied_Macroeconometrics")

# Loading packages and setting working directory ----

library(bruceR)
library(urca)
library(vars)
library(mFilter)
library(tseries)
library(TSstudio)
library(forecast)
library(aTSA)
library(ggplot2)
library(papeR)
library(magrittr)
library(munsell)
library(tsDyn)
library(lmtest)
library(Matrix)
library(uroot)
library(tempdisagg)
library(tsbox)
library(gamlss)


#_______________________________________________________________________________
# Read the data ----
#_______________________________________________________________________________

init_data <- as.data.frame(read.csv("Data_preparation_VAR.csv", 
                                    sep = ";", dec = ","))
head(init_data)

init_data_GAP <- as.data.frame(read.csv("GAP_Interpolation_Input.csv",
                                        sep = ";", dec = ","))
head(init_data_GAP)

#_______________________________________________________________________________
# Create Time Series ----
#_______________________________________________________________________________
CINF <- ts(init_data$CINF[5:84], start= c(2002,1), frequency = 4)
CINF


SPF <- ts(init_data$SPF[5:84], start = c(2002,1) , frequency = 4)
SPF
ts_plot(SPF)

EURIBOR <- ts(init_data$EURIBOR[5:84], start = c(2002,1), frequency = 4)
EURIBOR
ts_plot(EURIBOR)



EXR <- ts(init_data$EXR[5:84], start = c(2002,1), frequency = 4)
EXR


GAPPURE <- ts(init_data_GAP$GAPPURE[2:21], start = c(2002), frequency = 1)
GAPPURE
ts_plot(GAPPURE)

#_______________________________________________________________________________
# Transforming the Output Gap data ----
#_______________________________________________________________________________

GAP.a <- td(GAPPURE ~ 1, to = 4, conversion = "average", 
            method = "chow-lin-fixed", fixed.rho = 0.99)

GAP.q <- predict(GAP.a)

GAP <- ts(GAP.q, start = c(2002,1), end = c(2021,4), frequency = 4)
GAP
plot(GAP)

#_______________________________________________________________________________
#Plots ----
#_______________________________________________________________________________

op <- options(
  tsbox.lwd = 1,
  tsbox.col = c("#4d4d4d",  "#56b3e9", "#e7a514"),
  tsbox.lty = "solid"
)

ts_plot(cbind(CINF, SPF, EURIBOR), ylab = "Percent")
abline(a=0,b=0,col="red", lwd=1, lty=8)

ts_plot(EXR, ylab = "US-Dollar per Euro")

ts_plot(GAP, ylab = "Percent")
abline(a=0,b=0,col="red", lwd=1, lty=8)



#_______________________________________________________________________________
# Taking first differences ----
#_______________________________________________________________________________

CINF_df <- diff(CINF)
SPF_df <- diff(SPF)
EURIBOR_df <- diff(EURIBOR)
EXR_df <- diff(EXR)
GAP_df <- diff(GAP)
#_______________________________________________________________________________
# ADF-tests ----
#_______________________________________________________________________________


summary(ur.df(CINF, type = "trend", lags = 3))
summary(ur.df(SPF, type = "drift", lags = 1))
summary(ur.df(GAP, type = "none", lags = 2))
summary(ur.df(EURIBOR, type = "trend", lags = 1))
summary(ur.df(EXR, type = "trend", lags = 2))


summary(ur.df(CINF_df, type = "none", lags = 3))
summary(ur.df(SPF_df, type = "none", lags = 0))
summary(ur.df(GAP_df, type = "none", lags =1))
summary(ur.df(EURIBOR_df, type = "none", lags = 0))
summary(ur.df(EXR_df, type = "none", lags = 1))




#_______________________________________________________________________________
# Model estimation (5 Variables) ----
#_______________________________________________________________________________
## Lag selection ----
#_______________________________________________________________________________

data_lv_5 <- cbind(GAP, CINF, SPF, EURIBOR, EXR)
data_df_5 <- cbind(GAP_df, CINF_df, SPF_df, EURIBOR_df, EXR_df)

lagselect_5 <- VARselect(data_df_5 , type = "trend", lag.max = 5)
lagselect_5

#_______________________________________________________________________________
## Cointegration test ----
#_______________________________________________________________________________

vecm_5 <- ca.jo(data_lv_5, type = "trace", ecdet = "trend", K =  2,
                spec = "transitory", season = 4)

summary(vecm_5) 

# Diagnostic test

var_5 <- vec2var(vecm_5, r = 2)
serial.test(var_5, lags.pt = 16, type = "PT.asymptotic")
serial.test(var_5, lags.pt = 14, type = "PT.asymptotic")

vars:::arch.test(var_5, lags.multi = 6)
vars:::arch.test(var_5, lags.multi = 5)


#_______________________________________________________________________________
## Model identification ----
# ______________________________________________________________________________

# GAP, CINF, SPF, EURIBOR, EXR (Variable ordering)

bmat_5 <- matrix(c(1 , 0, 0, 0, NA,
                   NA, 1,NA, NA, 0,
                   0, NA, 1,NA,NA,
                   0, NA,NA, 1, NA,
                   NA, NA,NA,NA, 1), byrow = TRUE, nrow = 5)



lrmat_5 <- matrix(c(0, 0,NA,0,NA,
                    0,NA,NA,0,NA,
                    NA,NA,NA,NA,NA,
                    NA,NA,NA,NA,NA,
                    NA,NA,NA,NA,NA), byrow = TRUE, nrow = 5)


svec_5 <-SVEC(vecm_5, LR = lrmat_5, SR = bmat_5, r = 2, max.iter = 50000 )
summary(svec_5)


#_______________________________________________________________________________
## Impulse Response Analysis ----
#_______________________________________________________________________________

plot(irf(svec_5, impulse = "EXR" ,runs = 100, n.ahead = 40))
plot(irf(svec_5, impulse = "CINF" ,runs = 100, n.ahead = 40))
plot(irf(svec_5, impulse = "GAP" ,runs = 100, n.ahead = 40))
plot(irf(svec_5, impulse = "SPF" ,runs = 100, n.ahead = 40))
plot(irf(svec_5, impulse = "EURIBOR" ,runs = 100, n.ahead = 40))


#_______________________________________________________________________________
## FEVD
#_______________________________________________________________________________

fevd(svec_5, n.ahead = 40)$GAP
fevd(svec_5, n.ahead = 40)$EURIBOR
fevd(svec_5, n.ahead = 40)$CINF

